<?php

# table and vies names
$WSS_VIEW= 'wordsXsensesXsynsets';
$SEMLINK_TAB="semlinks";
$SYNSETS_TAB="synsets";
$WORDS_TAB="words";
$REL_TAB="linktypes";

# side tables
$GRCWS_TAB="grcWs";
$GRCMAP_TAB="grcMap";
$XPOSRULE_TAB="xPosGenerationRule";

# login table
$USER_TAB="users";
$USER_ACT_TAB="user_Activity";

?>