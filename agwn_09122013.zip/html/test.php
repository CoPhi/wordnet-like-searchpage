<?php
<? $words = $_POST['words']; ?>
echo "OK ".count($words);
?>