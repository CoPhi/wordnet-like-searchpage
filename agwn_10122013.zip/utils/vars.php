<?php
$debug = 0;
#$db_hostname = "wiki.ilc.cnr.it:3306";
#$db_hostname = "wiki2.ilc.cnr.it:3306";
$db_hostname = "localhost:3306";
$db_username = "wnuser";
$db_password = "wnuser";
$grc_database = "GWN";
$ara_database = "AWN";
$lat_database = "LWN";
$eng_database = "wordnet30";
$mapiwn_database = "IWNMAPDB";
$ita_database = "NEWIWN";
$side_grc_database = "side_GWN";
$login_database="login_AGWN";
$connection = false;



?>
