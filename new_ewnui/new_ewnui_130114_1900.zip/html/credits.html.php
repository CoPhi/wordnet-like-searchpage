<?php

    
?>
<div id="div_credits">

<table>
<tr><td>Powered by <a href="mailto:riccardo.delgratta@il.cnr.ir">Riccardo Del Gratta</a> </td><td>&nbsp;&nbsp;&nbsp;&nbsp;View <a href="./html/gnu_lic.html" target="_blank">License</a></td></tr>
</table>
</div>
</br>
</br>