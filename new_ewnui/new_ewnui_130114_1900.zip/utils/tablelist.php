<?php

# table and vies names
$WSS_VIEW= 'wordsXsensesXsynsets';
$SEMLINK_TAB="semlinks";
$SYNSETS_TAB="synsets";
$WORDS_TAB="words";
$REL_TAB="linktypes";
$POS_TAB="postypes";

# side tables
$GRCWS_TAB="grcWs";
$GRCMAP_TAB="grcMap";
$LATWS_TAB="latWs";
$LATMAP_TAB="latMap";
$XPOSRULE_TAB="xPosGenerationRule";

#IWN
$IWNWN30_ILI_TAB="iwn2wn30ililinks";

# login table
$USER_TAB="users";
$USER_ACT_TAB="user_words_activity";
$USER_ACT_SREL_TAB="user_srels_activity";
$USER_ACT_TREL_TAB="user_trels_activity";
$USER_LOG_TAB="logged_User";
$USER_SYN_TAB="user_synsets_activity";

?>